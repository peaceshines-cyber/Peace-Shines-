import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, CreditCard, Truck, Check, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useCart } from '@/context/CartContext';
import { toast } from 'sonner';

export default function Checkout() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { items, totalPrice, clearCart } = useCart();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState<'shipping' | 'payment'>('shipping');

  const shippingCost = totalPrice > 50 ? 0 : 5.99;
  const finalTotal = totalPrice + shippingCost;

  const [shippingData, setShippingData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    country: '',
    postalCode: '',
  });

  const [paymentData, setPaymentData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
  });

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-[hsl(var(--background))] pt-24 pb-16">
        <div className="container-elegant text-center">
          <h1 className="font-display text-2xl text-[hsl(var(--warm-brown))] mb-4">
            Your cart is empty
          </h1>
          <Link to="/products">
            <Button className="btn-elegant">Continue Shopping</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
    window.scrollTo(0, 0);
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000));

    toast.success(t('checkout.orderSuccess'));
    clearCart();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-[hsl(var(--background))] pt-24 pb-16">
      <div className="container-elegant">
        {/* Back Button */}
        <Link
          to="/cart"
          className="inline-flex items-center gap-2 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--warm-brown))] mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Cart
        </Link>

        <h1 className="font-display text-3xl md:text-4xl font-semibold text-[hsl(var(--warm-brown))] mb-8">
          {t('checkout.title')}
        </h1>

        {/* Progress */}
        <div className="flex items-center gap-4 mb-8">
          <div className={`flex items-center gap-2 ${step === 'shipping' ? 'text-[hsl(var(--warm-brown))]' : 'text-green-600'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              step === 'shipping' ? 'bg-[hsl(var(--warm-brown))] text-white' : 'bg-green-100'
            }`}>
              {step === 'payment' ? <Check className="w-5 h-5" /> : <Truck className="w-4 h-4" />}
            </div>
            <span className="font-medium">{t('checkout.shippingInfo')}</span>
          </div>
          <div className="flex-1 h-px bg-[hsl(var(--border))]" />
          <div className={`flex items-center gap-2 ${step === 'payment' ? 'text-[hsl(var(--warm-brown))]' : 'text-[hsl(var(--muted-foreground))]'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              step === 'payment' ? 'bg-[hsl(var(--warm-brown))] text-white' : 'bg-[hsl(var(--muted))]'
            }`}>
              <CreditCard className="w-4 h-4" />
            </div>
            <span className="font-medium">{t('checkout.paymentInfo')}</span>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Forms */}
          <div className="lg:col-span-2">
            {step === 'shipping' ? (
              <form onSubmit={handleShippingSubmit} className="bg-[hsl(var(--card))] rounded-2xl p-6 md:p-8">
                <h2 className="font-display text-xl font-semibold text-[hsl(var(--warm-brown))] mb-6">
                  {t('checkout.shippingInfo')}
                </h2>

                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">{t('checkout.firstName')} *</Label>
                    <Input
                      id="firstName"
                      value={shippingData.firstName}
                      onChange={(e) => setShippingData({ ...shippingData, firstName: e.target.value })}
                      required
                      className="bg-[hsl(var(--background))]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">{t('checkout.lastName')} *</Label>
                    <Input
                      id="lastName"
                      value={shippingData.lastName}
                      onChange={(e) => setShippingData({ ...shippingData, lastName: e.target.value })}
                      required
                      className="bg-[hsl(var(--background))]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">{t('checkout.email')} *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={shippingData.email}
                      onChange={(e) => setShippingData({ ...shippingData, email: e.target.value })}
                      required
                      className="bg-[hsl(var(--background))]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">{t('checkout.phone')} *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={shippingData.phone}
                      onChange={(e) => setShippingData({ ...shippingData, phone: e.target.value })}
                      required
                      className="bg-[hsl(var(--background))]"
                    />
                  </div>
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="address">{t('checkout.address')} *</Label>
                    <Input
                      id="address"
                      value={shippingData.address}
                      onChange={(e) => setShippingData({ ...shippingData, address: e.target.value })}
                      required
                      className="bg-[hsl(var(--background))]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="city">{t('checkout.city')} *</Label>
                    <Input
                      id="city"
                      value={shippingData.city}
                      onChange={(e) => setShippingData({ ...shippingData, city: e.target.value })}
                      required
                      className="bg-[hsl(var(--background))]"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="postalCode">{t('checkout.postalCode')} *</Label>
                    <Input
                      id="postalCode"
                      value={shippingData.postalCode}
                      onChange={(e) => setShippingData({ ...shippingData, postalCode: e.target.value })}
                      required
                      className="bg-[hsl(var(--background))]"
                    />
                  </div>
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="country">{t('checkout.country')} *</Label>
                    <Input
                      id="country"
                      value={shippingData.country}
                      onChange={(e) => setShippingData({ ...shippingData, country: e.target.value })}
                      required
                      className="bg-[hsl(var(--background))]"
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full mt-8 btn-elegant">
                  Continue to Payment
                </Button>
              </form>
            ) : (
              <form onSubmit={handlePaymentSubmit} className="bg-[hsl(var(--card))] rounded-2xl p-6 md:p-8">
                <div className="flex items-center gap-2 mb-6">
                  <Lock className="w-5 h-5 text-green-600" />
                  <h2 className="font-display text-xl font-semibold text-[hsl(var(--warm-brown))]">
                    {t('checkout.paymentInfo')}
                  </h2>
                </div>

                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="cardNumber">{t('checkout.cardNumber')} *</Label>
                    <Input
                      id="cardNumber"
                      placeholder="1234 5678 9012 3456"
                      value={paymentData.cardNumber}
                      onChange={(e) => setPaymentData({ ...paymentData, cardNumber: e.target.value })}
                      required
                      className="bg-[hsl(var(--background))]"
                    />
                  </div>
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="expiryDate">{t('checkout.expiryDate')} *</Label>
                      <Input
                        id="expiryDate"
                        placeholder="MM/YY"
                        value={paymentData.expiryDate}
                        onChange={(e) => setPaymentData({ ...paymentData, expiryDate: e.target.value })}
                        required
                        className="bg-[hsl(var(--background))]"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cvv">{t('checkout.cvv')} *</Label>
                      <Input
                        id="cvv"
                        placeholder="123"
                        value={paymentData.cvv}
                        onChange={(e) => setPaymentData({ ...paymentData, cvv: e.target.value })}
                        required
                        className="bg-[hsl(var(--background))]"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 mt-8">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setStep('shipping')}
                    className="flex-1"
                  >
                    Back
                  </Button>
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 btn-elegant"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Processing...
                      </span>
                    ) : (
                      t('checkout.placeOrder')
                    )}
                  </Button>
                </div>
              </form>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-[hsl(var(--card))] rounded-2xl p-6 sticky top-24">
              <h2 className="font-display text-xl font-semibold text-[hsl(var(--warm-brown))] mb-6">
                {t('checkout.orderSummary')}
              </h2>

              {/* Items */}
              <div className="space-y-4 mb-6 max-h-60 overflow-auto">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-3">
                    <div className="w-16 h-16 bg-[hsl(var(--muted))] rounded-lg overflow-hidden flex-shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium line-clamp-1">{item.name}</p>
                      <p className="text-xs text-[hsl(var(--muted-foreground))]">
                        Qty: {item.quantity}
                      </p>
                    </div>
                    <p className="font-medium text-sm">
                      ${(item.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                ))}
              </div>

              <div className="border-t border-[hsl(var(--border))] pt-4 space-y-3">
                <div className="flex justify-between text-[hsl(var(--muted-foreground))]">
                  <span>{t('cart.subtotal')}</span>
                  <span>${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[hsl(var(--muted-foreground))]">
                  <span>{t('cart.shipping')}</span>
                  <span>{shippingCost === 0 ? 'Free' : `$${shippingCost.toFixed(2)}`}</span>
                </div>
                <div className="border-t border-[hsl(var(--border))] pt-3">
                  <div className="flex justify-between font-display text-xl font-semibold text-[hsl(var(--warm-brown))]">
                    <span>{t('cart.total')}</span>
                    <span>${finalTotal.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
