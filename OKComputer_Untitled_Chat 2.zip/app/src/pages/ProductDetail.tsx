import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, Link } from 'react-router-dom';
import { Star, Minus, Plus, ShoppingBag, Heart, Share2, Check, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getProductById, products } from '@/data/products';
import { useCart } from '@/context/CartContext';
import { toast } from 'sonner';

export default function ProductDetail() {
  const { t } = useTranslation();
  const { id } = useParams<{ id: string }>();
  const { addItem } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [isWishlisted, setIsWishlisted] = useState(false);

  const product = getProductById(id || '');
  const relatedProducts = products
    .filter((p) => p.category === product?.category && p.id !== id)
    .slice(0, 4);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-2xl text-[hsl(var(--warm-brown))] mb-4">
            Product not found
          </h1>
          <Link to="/products">
            <Button className="btn-elegant">Back to Products</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addItem({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        category: product.category,
      });
    }
    toast.success(`${product.name} added to cart!`);
  };

  const handleWishlist = () => {
    setIsWishlisted(!isWishlisted);
    toast.success(isWishlisted ? 'Removed from wishlist' : 'Added to wishlist!');
  };

  return (
    <div className="min-h-screen bg-[hsl(var(--background))] pt-24 pb-16">
      <div className="container-elegant">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 mb-8 text-sm">
          <Link to="/" className="text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--warm-brown))]">
            {t('nav.home')}
          </Link>
          <span className="text-[hsl(var(--muted-foreground))]">/</span>
          <Link to="/products" className="text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--warm-brown))]">
            {t('nav.products')}
          </Link>
          <span className="text-[hsl(var(--muted-foreground))]">/</span>
          <span className="text-[hsl(var(--warm-brown))]">{product.name}</span>
        </div>

        {/* Back Button */}
        <Link
          to="/products"
          className="inline-flex items-center gap-2 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--warm-brown))] mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Products
        </Link>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Images */}
          <div>
            <div className="aspect-square bg-[hsl(var(--muted))] rounded-2xl overflow-hidden mb-4">
              <img
                src={product.images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            {product.images.length > 1 && (
              <div className="flex gap-3">
                {product.images.map((img, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImage === index
                        ? 'border-[hsl(var(--warm-brown))]'
                        : 'border-transparent'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div>
            {/* Badges */}
            <div className="flex gap-2 mb-4">
              {product.isNew && (
                <Badge className="bg-[hsl(var(--accent))]">New</Badge>
              )}
              {product.isBestseller && (
                <Badge className="bg-[hsl(var(--warm-brown))]">Bestseller</Badge>
              )}
              {!product.inStock && (
                <Badge variant="destructive">Out of Stock</Badge>
              )}
            </div>

            {/* Title */}
            <h1 className="font-display text-3xl md:text-4xl font-semibold text-[hsl(var(--warm-brown))] mb-4">
              {product.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-3 mb-4">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor(product.rating)
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-[hsl(var(--muted-foreground))]">
                {product.rating} ({product.reviews} reviews)
              </span>
            </div>

            {/* Price */}
            <div className="flex items-center gap-3 mb-6">
              <span className="font-display text-3xl font-semibold text-[hsl(var(--warm-brown))]">
                ${product.price.toFixed(2)}
              </span>
              {product.originalPrice && (
                <span className="text-xl text-[hsl(var(--muted-foreground))] line-through">
                  ${product.originalPrice.toFixed(2)}
                </span>
              )}
            </div>

            {/* Description */}
            <p className="text-[hsl(var(--muted-foreground))] leading-relaxed mb-6">
              {product.description}
            </p>

            {/* Stock Status */}
            <div className="flex items-center gap-2 mb-6">
              {product.inStock ? (
                <>
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-green-600 font-medium">{t('productDetail.inStock')}</span>
                </>
              ) : (
                <span className="text-red-500 font-medium">{t('productDetail.outOfStock')}</span>
              )}
            </div>

            {/* Quantity & Actions */}
            {product.inStock && (
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                {/* Quantity Selector */}
                <div className="flex items-center border border-[hsl(var(--border))] rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-3 hover:bg-[hsl(var(--muted))] transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="px-4 font-medium">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-3 hover:bg-[hsl(var(--muted))] transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                {/* Add to Cart */}
                <Button
                  onClick={handleAddToCart}
                  className="flex-1 btn-elegant"
                >
                  <ShoppingBag className="w-5 h-5 mr-2" />
                  {t('productDetail.addToCart')}
                </Button>

                {/* Wishlist */}
                <Button
                  variant="outline"
                  onClick={handleWishlist}
                  className={`px-4 ${isWishlisted ? 'bg-red-50 border-red-200' : ''}`}
                >
                  <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-red-500 text-red-500' : ''}`} />
                </Button>

                {/* Share */}
                <Button variant="outline" className="px-4">
                  <Share2 className="w-5 h-5" />
                </Button>
              </div>
            )}

            {/* Tabs */}
            <Tabs defaultValue="description" className="w-full">
              <TabsList className="w-full bg-[hsl(var(--muted))]">
                <TabsTrigger value="description" className="flex-1">
                  {t('productDetail.description')}
                </TabsTrigger>
                <TabsTrigger value="specifications" className="flex-1">
                  {t('productDetail.specifications')}
                </TabsTrigger>
                <TabsTrigger value="reviews" className="flex-1">
                  {t('productDetail.reviews')}
                </TabsTrigger>
              </TabsList>
              <TabsContent value="description" className="mt-4">
                <p className="text-[hsl(var(--muted-foreground))] leading-relaxed">
                  {product.description}
                </p>
              </TabsContent>
              <TabsContent value="specifications" className="mt-4">
                <div className="space-y-3">
                  <div className="flex justify-between py-2 border-b border-[hsl(var(--border))]">
                    <span className="text-[hsl(var(--muted-foreground))]">Material</span>
                    <span className="font-medium">{product.material}</span>
                  </div>
                  {product.dimensions && (
                    <div className="flex justify-between py-2 border-b border-[hsl(var(--border))]">
                      <span className="text-[hsl(var(--muted-foreground))]">Dimensions</span>
                      <span className="font-medium">{product.dimensions}</span>
                    </div>
                  )}
                  {product.weight && (
                    <div className="flex justify-between py-2 border-b border-[hsl(var(--border))]">
                      <span className="text-[hsl(var(--muted-foreground))]">Weight</span>
                      <span className="font-medium">{product.weight}</span>
                    </div>
                  )}
                </div>
              </TabsContent>
              <TabsContent value="reviews" className="mt-4">
                <p className="text-[hsl(var(--muted-foreground))]">
                  {product.reviews} customer reviews with an average rating of {product.rating} stars.
                </p>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-20">
            <h2 className="font-display text-2xl font-semibold text-[hsl(var(--warm-brown))] mb-8">
              {t('productDetail.relatedProducts')}
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {relatedProducts.map((item) => (
                <Link
                  key={item.id}
                  to={`/product/${item.id}`}
                  className="group"
                >
                  <div className="aspect-square bg-[hsl(var(--muted))] rounded-xl overflow-hidden mb-3">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  </div>
                  <h3 className="font-medium text-[hsl(var(--foreground))] group-hover:text-[hsl(var(--warm-brown))] transition-colors line-clamp-1">
                    {item.name}
                  </h3>
                  <p className="font-display text-lg text-[hsl(var(--warm-brown))]">
                    ${item.price.toFixed(2)}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
