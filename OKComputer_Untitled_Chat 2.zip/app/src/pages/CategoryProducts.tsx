import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, Link } from 'react-router-dom';
import { ShoppingBag, Star, Heart, Eye, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { getProductsByCategory, categories } from '@/data/products';
import { useCart } from '@/context/CartContext';
import { toast } from 'sonner';

export default function CategoryProducts() {
  const { t } = useTranslation();
  const { categoryId } = useParams<{ categoryId: string }>();
  const { addItem } = useCart();
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const category = categories.find((c) => c.id === categoryId);
  const products = getProductsByCategory(categoryId || '');

  if (!category) {
    return (
      <div className="min-h-screen bg-[hsl(var(--background))] pt-24 pb-16">
        <div className="container-elegant text-center">
          <h1 className="font-display text-2xl text-[hsl(var(--warm-brown))] mb-4">
            Category not found
          </h1>
          <Link to="/collections">
            <Button className="btn-elegant">View All Collections</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = (product: typeof products[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
    });
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <div className="min-h-screen bg-[hsl(var(--background))] pt-24 pb-16">
      <div className="container-elegant">
        {/* Back Button */}
        <Link
          to="/collections"
          className="inline-flex items-center gap-2 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--warm-brown))] mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Collections
        </Link>

        {/* Header */}
        <div className="relative rounded-2xl overflow-hidden mb-12">
          <div className="aspect-[21/9] md:aspect-[3/1]">
            <img
              src={category.image}
              alt={t(`collections.${category.id}`)}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/40" />
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-white">
              <h1 className="font-display text-4xl md:text-5xl font-semibold mb-2">
                {t(`collections.${category.id}`)}
              </h1>
              <p className="text-white/80">
                {products.length} Products
              </p>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        {products.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <div
                key={product.id}
                className="group bg-[hsl(var(--card))] rounded-2xl overflow-hidden card-elegant"
                onMouseEnter={() => setHoveredId(product.id)}
                onMouseLeave={() => setHoveredId(null)}
              >
                {/* Image */}
                <div className="relative aspect-square overflow-hidden bg-[hsl(var(--muted))]">
                  <Link to={`/product/${product.id}`}>
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                  </Link>

                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex flex-col gap-2">
                    {product.isNew && (
                      <Badge className="bg-[hsl(var(--accent))] text-white text-xs">New</Badge>
                    )}
                    {product.isBestseller && (
                      <Badge className="bg-[hsl(var(--warm-brown))] text-white text-xs">Bestseller</Badge>
                    )}
                    {product.originalPrice && (
                      <Badge className="bg-red-500 text-white text-xs">Sale</Badge>
                    )}
                  </div>

                  {/* Quick Actions */}
                  <div className={`absolute top-3 right-3 flex flex-col gap-2 transition-all duration-300 ${
                    hoveredId === product.id ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
                  }`}>
                    <button className="w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-[hsl(var(--warm-brown))] hover:text-white transition-colors">
                      <Heart className="w-4 h-4" />
                    </button>
                    <Link
                      to={`/product/${product.id}`}
                      className="w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-[hsl(var(--warm-brown))] hover:text-white transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                    </Link>
                  </div>

                  {/* Add to Cart */}
                  <div className={`absolute bottom-0 left-0 right-0 p-3 transition-all duration-300 ${
                    hoveredId === product.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-full'
                  }`}>
                    <Button
                      onClick={() => handleAddToCart(product)}
                      className="w-full bg-[hsl(var(--warm-brown))] hover:bg-[hsl(var(--deep-bronze))] text-white"
                    >
                      <ShoppingBag className="w-4 h-4 mr-2" />
                      {t('products.addToCart')}
                    </Button>
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  <Link to={`/product/${product.id}`}>
                    <h3 className="font-display text-lg font-medium text-[hsl(var(--foreground))] hover:text-[hsl(var(--warm-brown))] transition-colors line-clamp-1">
                      {product.name}
                    </h3>
                  </Link>
                  <div className="flex items-center gap-1 mt-2">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span className="text-sm text-[hsl(var(--muted-foreground))]">
                      {product.rating} ({product.reviews})
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="font-display text-xl font-semibold text-[hsl(var(--warm-brown))]">
                      ${product.price.toFixed(2)}
                    </span>
                    {product.originalPrice && (
                      <span className="text-sm text-[hsl(var(--muted-foreground))] line-through">
                        ${product.originalPrice.toFixed(2)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-[hsl(var(--muted-foreground))] text-lg mb-4">
              No products available in this category yet.
            </p>
            <Link to="/products">
              <Button className="btn-elegant">Browse All Products</Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
