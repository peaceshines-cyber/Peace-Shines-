import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { ShoppingBag, Star, Heart, Eye, SlidersHorizontal, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { products, categories } from '@/data/products';
import { useCart } from '@/context/CartContext';
import { toast } from 'sonner';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';

export default function ProductsPage() {
  const { t } = useTranslation();
  const { addItem } = useCart();
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<'price-low' | 'price-high' | 'newest' | 'popular'>('newest');
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  // Filter products
  let filteredProducts = selectedCategories.length > 0
    ? products.filter((p) => selectedCategories.includes(p.category))
    : products;

  // Sort products
  filteredProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'popular':
        return b.reviews - a.reviews;
      case 'newest':
      default:
        return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
    }
  });

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId)
        ? prev.filter((c) => c !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleAddToCart = (product: typeof products[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
    });
    toast.success(`${product.name} added to cart!`);
  };

  const clearFilters = () => {
    setSelectedCategories([]);
  };

  return (
    <div className="min-h-screen bg-[hsl(var(--background))] pt-24 pb-16">
      <div className="container-elegant">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-8">
          <div>
            <span className="inline-block text-sm font-medium text-[hsl(var(--accent))] tracking-widest uppercase mb-4">
              Browse
            </span>
            <h1 className="font-display text-4xl md:text-5xl font-semibold text-[hsl(var(--warm-brown))]">
              {t('nav.products')}
            </h1>
          </div>
          <p className="text-[hsl(var(--muted-foreground))] mt-4 md:mt-0">
            {filteredProducts.length} products
          </p>
        </div>

        {/* Filters & Sort */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          {/* Mobile Filter */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="lg:hidden">
                <SlidersHorizontal className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80">
              <SheetHeader>
                <SheetTitle className="font-display text-xl text-[hsl(var(--warm-brown))]">
                  Filters
                </SheetTitle>
              </SheetHeader>
              <div className="mt-6">
                <h3 className="font-medium mb-4">{t('products.categories')}</h3>
                <div className="space-y-3">
                  {categories.map((cat) => (
                    <div key={cat.id} className="flex items-center gap-2">
                      <Checkbox
                        id={`mobile-${cat.id}`}
                        checked={selectedCategories.includes(cat.id)}
                        onCheckedChange={() => toggleCategory(cat.id)}
                      />
                      <label htmlFor={`mobile-${cat.id}`} className="text-sm cursor-pointer">
                        {t(`collections.${cat.id}`)}
                      </label>
                    </div>
                  ))}
                </div>
                {selectedCategories.length > 0 && (
                  <Button
                    variant="ghost"
                    onClick={clearFilters}
                    className="mt-4 text-red-500"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Clear Filters
                  </Button>
                )}
              </div>
            </SheetContent>
          </Sheet>

          {/* Desktop Filter */}
          <div className="hidden lg:flex items-center gap-2 flex-wrap">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => toggleCategory(cat.id)}
                className={`px-4 py-2 rounded-full text-sm transition-all ${
                  selectedCategories.includes(cat.id)
                    ? 'bg-[hsl(var(--warm-brown))] text-white'
                    : 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--warm-brown))]/10'
                }`}
              >
                {t(`collections.${cat.id}`)}
              </button>
            ))}
            {selectedCategories.length > 0 && (
              <button
                onClick={clearFilters}
                className="px-4 py-2 rounded-full text-sm text-red-500 hover:bg-red-50 transition-all"
              >
                Clear All
              </button>
            )}
          </div>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="px-4 py-2 bg-[hsl(var(--card))] border border-[hsl(var(--border))] rounded-lg text-sm focus:outline-none focus:border-[hsl(var(--warm-brown))]"
          >
            <option value="newest">Newest</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="popular">Most Popular</option>
          </select>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="group bg-[hsl(var(--card))] rounded-2xl overflow-hidden card-elegant"
              onMouseEnter={() => setHoveredId(product.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              {/* Image */}
              <div className="relative aspect-square overflow-hidden bg-[hsl(var(--muted))]">
                <Link to={`/product/${product.id}`}>
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </Link>

                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  {product.isNew && (
                    <Badge className="bg-[hsl(var(--accent))] text-white text-xs">New</Badge>
                  )}
                  {product.isBestseller && (
                    <Badge className="bg-[hsl(var(--warm-brown))] text-white text-xs">Bestseller</Badge>
                  )}
                  {product.originalPrice && (
                    <Badge className="bg-red-500 text-white text-xs">Sale</Badge>
                  )}
                </div>

                {/* Quick Actions */}
                <div className={`absolute top-3 right-3 flex flex-col gap-2 transition-all duration-300 ${
                  hoveredId === product.id ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
                }`}>
                  <button className="w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-[hsl(var(--warm-brown))] hover:text-white transition-colors">
                    <Heart className="w-4 h-4" />
                  </button>
                  <Link
                    to={`/product/${product.id}`}
                    className="w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-[hsl(var(--warm-brown))] hover:text-white transition-colors"
                  >
                    <Eye className="w-4 h-4" />
                  </Link>
                </div>

                {/* Add to Cart */}
                <div className={`absolute bottom-0 left-0 right-0 p-3 transition-all duration-300 ${
                  hoveredId === product.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-full'
                }`}>
                  <Button
                    onClick={() => handleAddToCart(product)}
                    className="w-full bg-[hsl(var(--warm-brown))] hover:bg-[hsl(var(--deep-bronze))] text-white"
                  >
                    <ShoppingBag className="w-4 h-4 mr-2" />
                    {t('products.addToCart')}
                  </Button>
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                <Link to={`/product/${product.id}`}>
                  <h3 className="font-display text-lg font-medium text-[hsl(var(--foreground))] hover:text-[hsl(var(--warm-brown))] transition-colors line-clamp-1">
                    {product.name}
                  </h3>
                </Link>
                <div className="flex items-center gap-1 mt-2">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="text-sm text-[hsl(var(--muted-foreground))]">
                    {product.rating} ({product.reviews})
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <span className="font-display text-xl font-semibold text-[hsl(var(--warm-brown))]">
                    ${product.price.toFixed(2)}
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm text-[hsl(var(--muted-foreground))] line-through">
                      ${product.originalPrice.toFixed(2)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <p className="text-[hsl(var(--muted-foreground))] text-lg mb-4">
              No products found matching your filters.
            </p>
            <Button onClick={clearFilters} variant="outline">
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
