import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { categories } from '@/data/products';

export default function CollectionsPage() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-[hsl(var(--background))] pt-24 pb-16">
      <div className="container-elegant">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-sm font-medium text-[hsl(var(--accent))] tracking-widest uppercase mb-4">
            Explore
          </span>
          <h1 className="font-display text-4xl md:text-5xl font-semibold text-[hsl(var(--warm-brown))] mb-4">
            {t('collections.title')}
          </h1>
          <p className="text-[hsl(var(--muted-foreground))] max-w-xl mx-auto">
            {t('collections.subtitle')}
          </p>
        </div>

        {/* Collections Grid */}
        <div className="grid md:grid-cols-2 gap-8">
          {categories.map((category, index) => (
            <Link
              key={category.id}
              to={`/collections/${category.id}`}
              className={`group relative overflow-hidden rounded-2xl ${
                index === 0 ? 'md:col-span-2 aspect-[21/9]' : 'aspect-[4/3]'
              }`}
            >
              <div className="img-zoom h-full">
                <img
                  src={category.image}
                  alt={t(`collections.${category.id}`)}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute inset-0 gradient-overlay" />
              <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
                <div className="flex items-end justify-between">
                  <div>
                    <h2 className={`font-display font-semibold text-white mb-2 ${
                      index === 0 ? 'text-3xl md:text-4xl' : 'text-2xl md:text-3xl'
                    }`}>
                      {t(`collections.${category.id}`)}
                    </h2>
                    <p className="text-white/80">
                      {20 + index * 5} Products
                    </p>
                  </div>
                  <div className={`bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:bg-white group-hover:scale-110 transition-all duration-300 ${
                    index === 0 ? 'w-14 h-14' : 'w-12 h-12'
                  }`}>
                    <ArrowUpRight className={`text-white group-hover:text-[hsl(var(--warm-brown))] transition-colors ${
                      index === 0 ? 'w-6 h-6' : 'w-5 h-5'
                    }`} />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
