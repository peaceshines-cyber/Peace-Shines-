import { useTranslation } from 'react-i18next';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, Trash2, Minus, Plus, ArrowRight, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/context/CartContext';
import { toast } from 'sonner';

export default function Cart() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { items, removeItem, updateQuantity, totalPrice, clearCart } = useCart();

  const shippingCost = totalPrice > 50 ? 0 : 5.99;
  const finalTotal = totalPrice + shippingCost;

  const handleCheckout = () => {
    if (items.length === 0) {
      toast.error('Your cart is empty!');
      return;
    }
    navigate('/checkout');
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-[hsl(var(--background))] pt-24 pb-16">
        <div className="container-elegant">
          <div className="text-center py-20">
            <div className="w-24 h-24 bg-[hsl(var(--champagne))] rounded-full flex items-center justify-center mx-auto mb-6">
              <ShoppingBag className="w-12 h-12 text-[hsl(var(--warm-brown))]" />
            </div>
            <h1 className="font-display text-3xl font-semibold text-[hsl(var(--warm-brown))] mb-4">
              {t('cart.empty')}
            </h1>
            <p className="text-[hsl(var(--muted-foreground))] mb-8">
              Discover our beautiful collection and add something special.
            </p>
            <Link to="/products">
              <Button className="btn-elegant">
                {t('cart.continueShopping')}
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(var(--background))] pt-24 pb-16">
      <div className="container-elegant">
        <h1 className="font-display text-3xl md:text-4xl font-semibold text-[hsl(var(--warm-brown))] mb-8">
          {t('cart.title')}
        </h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="bg-[hsl(var(--card))] rounded-2xl overflow-hidden">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-4 p-6 border-b border-[hsl(var(--border))] last:border-b-0"
                >
                  {/* Image */}
                  <Link to={`/product/${item.id}`} className="w-24 h-24 bg-[hsl(var(--muted))] rounded-xl overflow-hidden flex-shrink-0">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </Link>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <Link to={`/product/${item.id}`}>
                      <h3 className="font-medium text-[hsl(var(--foreground))] hover:text-[hsl(var(--warm-brown))] transition-colors line-clamp-1">
                        {item.name}
                      </h3>
                    </Link>
                    <p className="text-sm text-[hsl(var(--muted-foreground))] capitalize mb-2">
                      {item.category}
                    </p>
                    <p className="font-display text-lg text-[hsl(var(--warm-brown))]">
                      ${item.price.toFixed(2)}
                    </p>
                  </div>

                  {/* Quantity & Actions */}
                  <div className="flex flex-col items-end justify-between">
                    <button
                      onClick={() => removeItem(item.id)}
                      className="p-2 text-[hsl(var(--muted-foreground))] hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                    <div className="flex items-center border border-[hsl(var(--border))] rounded-lg">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-2 hover:bg-[hsl(var(--muted))] transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="px-3 font-medium min-w-[2rem] text-center">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-2 hover:bg-[hsl(var(--muted))] transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 mt-6">
              <Link to="/products" className="flex-1">
                <Button variant="outline" className="w-full btn-outline-elegant">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  {t('cart.continueShopping')}
                </Button>
              </Link>
              <Button
                variant="outline"
                onClick={clearCart}
                className="flex-1 text-red-500 border-red-200 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Clear Cart
              </Button>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-[hsl(var(--card))] rounded-2xl p-6 sticky top-24">
              <h2 className="font-display text-xl font-semibold text-[hsl(var(--warm-brown))] mb-6">
                {t('checkout.orderSummary')}
              </h2>

              <div className="space-y-4 mb-6">
                <div className="flex justify-between text-[hsl(var(--muted-foreground))]">
                  <span>{t('cart.subtotal')}</span>
                  <span>${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[hsl(var(--muted-foreground))]">
                  <span>{t('cart.shipping')}</span>
                  <span>{shippingCost === 0 ? 'Free' : `$${shippingCost.toFixed(2)}`}</span>
                </div>
                {shippingCost === 0 && (
                  <p className="text-sm text-green-600">
                    You got free shipping!
                  </p>
                )}
                <div className="border-t border-[hsl(var(--border))] pt-4">
                  <div className="flex justify-between font-display text-xl font-semibold text-[hsl(var(--warm-brown))]">
                    <span>{t('cart.total')}</span>
                    <span>${finalTotal.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <Button
                onClick={handleCheckout}
                className="w-full btn-elegant"
              >
                {t('cart.checkout')}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>

              <p className="text-center text-sm text-[hsl(var(--muted-foreground))] mt-4">
                Shipping & taxes calculated at checkout
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
