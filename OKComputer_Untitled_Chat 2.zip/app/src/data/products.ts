export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: 'necklaces' | 'earrings' | 'bracelets' | 'rings' | 'sets';
  image: string;
  images: string[];
  rating: number;
  reviews: number;
  inStock: boolean;
  isNew?: boolean;
  isBestseller?: boolean;
  material: string;
  dimensions?: string;
  weight?: string;
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Eternal Grace Necklace',
    description: 'A stunning necklace featuring a delicate pendant that captures the essence of timeless elegance. Perfect for both everyday wear and special occasions.',
    price: 45.99,
    originalPrice: 59.99,
    category: 'necklaces',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&h=600&fit=crop',
    ],
    rating: 4.8,
    reviews: 124,
    inStock: true,
    isBestseller: true,
    material: 'Stainless Steel',
    dimensions: '45cm chain',
    weight: '8g',
  },
  {
    id: '2',
    name: 'Moonlight Earrings',
    description: 'These elegant drop earrings shimmer with every movement, inspired by the gentle glow of moonlight. Lightweight and comfortable for all-day wear.',
    price: 32.99,
    category: 'earrings',
    image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=600&h=600&fit=crop',
    ],
    rating: 4.9,
    reviews: 89,
    inStock: true,
    isNew: true,
    material: 'Stainless Steel',
    dimensions: '3cm drop',
    weight: '4g',
  },
  {
    id: '3',
    name: 'Royal Charm Bracelet',
    description: 'A beautiful charm bracelet that tells your unique story. Each charm represents a special moment, making it a perfect gift for loved ones.',
    price: 38.99,
    originalPrice: 48.99,
    category: 'bracelets',
    image: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=600&h=600&fit=crop',
    ],
    rating: 4.7,
    reviews: 156,
    inStock: true,
    isBestseller: true,
    material: 'Stainless Steel',
    dimensions: '18cm adjustable',
    weight: '12g',
  },
  {
    id: '4',
    name: 'Promise Ring',
    description: 'A delicate ring symbolizing love and commitment. Its minimalist design makes it perfect for stacking or wearing alone.',
    price: 28.99,
    category: 'rings',
    image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1598560917505-59a3ad559071?w=600&h=600&fit=crop',
    ],
    rating: 4.6,
    reviews: 203,
    inStock: true,
    material: 'Stainless Steel',
    dimensions: 'Adjustable',
    weight: '3g',
  },
  {
    id: '5',
    name: 'Complete Elegance Set',
    description: 'A matching set of necklace, earrings, and bracelet designed to create a cohesive, sophisticated look. The perfect choice for special occasions.',
    price: 89.99,
    originalPrice: 119.99,
    category: 'sets',
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&h=600&fit=crop',
    ],
    rating: 4.9,
    reviews: 67,
    inStock: true,
    isNew: true,
    material: 'Stainless Steel',
    dimensions: 'Various',
    weight: '25g',
  },
  {
    id: '6',
    name: 'Pearl Drop Necklace',
    description: 'Classic pearl drop necklace that exudes sophistication. A timeless piece that complements any outfit, from casual to formal.',
    price: 52.99,
    category: 'necklaces',
    image: 'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1599643477877-530eb83abc8e?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&h=600&fit=crop',
    ],
    rating: 4.8,
    reviews: 145,
    inStock: true,
    material: 'Stainless Steel & Pearl',
    dimensions: '50cm chain',
    weight: '10g',
  },
  {
    id: '7',
    name: 'Starlight Stud Earrings',
    description: 'Delicate star-shaped stud earrings that add a touch of sparkle to your everyday look. Comfortable and secure for all-day wear.',
    price: 24.99,
    category: 'earrings',
    image: 'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=600&h=600&fit=crop',
    ],
    rating: 4.5,
    reviews: 98,
    inStock: true,
    isNew: true,
    material: 'Stainless Steel',
    dimensions: '1cm',
    weight: '2g',
  },
  {
    id: '8',
    name: 'Infinity Bangle',
    description: 'A sleek infinity bangle representing eternal love and connection. Its adjustable design ensures a perfect fit for every wrist.',
    price: 35.99,
    category: 'bracelets',
    image: 'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=600&h=600&fit=crop',
    ],
    rating: 4.7,
    reviews: 112,
    inStock: true,
    material: 'Stainless Steel',
    dimensions: '6cm diameter',
    weight: '15g',
  },
  {
    id: '9',
    name: 'Floral Ring',
    description: 'A beautiful floral-inspired ring that brings nature\'s elegance to your fingertips. Intricate details make this piece truly special.',
    price: 31.99,
    originalPrice: 39.99,
    category: 'rings',
    image: 'https://images.unsplash.com/photo-1598560917505-59a3ad559071?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1598560917505-59a3ad559071?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=600&h=600&fit=crop',
    ],
    rating: 4.6,
    reviews: 78,
    inStock: true,
    material: 'Stainless Steel',
    dimensions: 'Adjustable',
    weight: '4g',
  },
  {
    id: '10',
    name: 'Bridal Dreams Set',
    description: 'An exquisite bridal jewelry set featuring a statement necklace, elegant earrings, and a delicate bracelet. Perfect for your special day.',
    price: 129.99,
    originalPrice: 169.99,
    category: 'sets',
    image: 'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&h=600&fit=crop',
    ],
    rating: 5.0,
    reviews: 45,
    inStock: true,
    isBestseller: true,
    material: 'Stainless Steel & Crystal',
    dimensions: 'Various',
    weight: '35g',
  },
  {
    id: '11',
    name: 'Heart Pendant Necklace',
    description: 'A romantic heart-shaped pendant that symbolizes love and affection. A meaningful gift for someone special in your life.',
    price: 42.99,
    category: 'necklaces',
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&h=600&fit=crop',
    ],
    rating: 4.8,
    reviews: 167,
    inStock: true,
    material: 'Stainless Steel',
    dimensions: '40cm chain',
    weight: '7g',
  },
  {
    id: '12',
    name: 'Crystal Hoop Earrings',
    description: 'Classic hoop earrings adorned with sparkling crystals. These versatile earrings transition effortlessly from day to night.',
    price: 29.99,
    category: 'earrings',
    image: 'https://images.unsplash.com/photo-1630019852942-f89202989a59?w=600&h=600&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1630019852942-f89202989a59?w=600&h=600&fit=crop',
      'https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=600&h=600&fit=crop',
    ],
    rating: 4.7,
    reviews: 134,
    inStock: true,
    isBestseller: true,
    material: 'Stainless Steel & Crystal',
    dimensions: '2.5cm diameter',
    weight: '5g',
  },
];

export const categories = [
  { id: 'necklaces', name: 'Necklaces', image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=400&h=400&fit=crop' },
  { id: 'earrings', name: 'Earrings', image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=400&h=400&fit=crop' },
  { id: 'bracelets', name: 'Bracelets', image: 'https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=400&h=400&fit=crop' },
  { id: 'rings', name: 'Rings', image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=400&h=400&fit=crop' },
  { id: 'sets', name: 'Jewelry Sets', image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400&h=400&fit=crop' },
];

export function getProductById(id: string): Product | undefined {
  return products.find((p) => p.id === id);
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter((p) => p.category === category);
}

export function getFeaturedProducts(): Product[] {
  return products.filter((p) => p.isBestseller || p.isNew).slice(0, 8);
}
