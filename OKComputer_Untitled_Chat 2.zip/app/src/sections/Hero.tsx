import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Hero() {
  const { t } = useTranslation();

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1920&h=1080&fit=crop"
          alt="Elegant Jewelry"
          className="w-full h-full object-cover"
        />
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[hsl(var(--cream))]/95 via-[hsl(var(--cream))]/70 to-transparent" />
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 right-10 w-64 h-64 bg-[hsl(var(--rose-gold))]/20 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-10 w-48 h-48 bg-[hsl(var(--soft-silver))]/20 rounded-full blur-3xl" />

      {/* Content */}
      <div className="relative z-10 container-elegant pt-20">
        <div className="max-w-2xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-[hsl(var(--warm-brown))]/10 rounded-full mb-6 animate-fadeIn">
            <Sparkles className="w-4 h-4 text-[hsl(var(--warm-brown))]" />
            <span className="text-sm font-medium text-[hsl(var(--warm-brown))]">
              {t('hero.subtitle')}
            </span>
          </div>

          {/* Title */}
          <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-semibold text-[hsl(var(--warm-brown))] leading-tight mb-6 animate-fadeInUp">
            {t('hero.title')}
          </h1>

          {/* Description */}
          <p className="text-lg md:text-xl text-[hsl(var(--muted-foreground))] leading-relaxed mb-8 max-w-xl animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
            {t('hero.description')}
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 animate-fadeInUp" style={{ animationDelay: '0.4s' }}>
            <Link to="/products">
              <Button
                size="lg"
                className="btn-elegant group"
              >
                {t('hero.ctaShop')}
                <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
            <Link to="/collections">
              <Button
                size="lg"
                variant="outline"
                className="btn-outline-elegant"
              >
                {t('hero.ctaCollections')}
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="flex gap-8 mt-12 pt-8 border-t border-[hsl(var(--border))] animate-fadeInUp" style={{ animationDelay: '0.6s' }}>
            <div>
              <p className="font-display text-3xl font-semibold text-[hsl(var(--warm-brown))]">500+</p>
              <p className="text-sm text-[hsl(var(--muted-foreground))]">Unique Designs</p>
            </div>
            <div>
              <p className="font-display text-3xl font-semibold text-[hsl(var(--warm-brown))]">10K+</p>
              <p className="text-sm text-[hsl(var(--muted-foreground))]">Happy Customers</p>
            </div>
            <div>
              <p className="font-display text-3xl font-semibold text-[hsl(var(--warm-brown))]">4.9</p>
              <p className="text-sm text-[hsl(var(--muted-foreground))]">Average Rating</p>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-[hsl(var(--warm-brown))]/30 rounded-full flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-[hsl(var(--warm-brown))]/50 rounded-full" />
        </div>
      </div>
    </section>
  );
}
