import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { categories } from '@/data/products';

export default function Collections() {
  const { t } = useTranslation();

  return (
    <section className="section-padding bg-[hsl(var(--background))]">
      <div className="container-elegant">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-sm font-medium text-[hsl(var(--accent))] tracking-widest uppercase mb-4">
            {t('collections.title')}
          </span>
          <h2 className="font-display text-4xl md:text-5xl font-semibold text-[hsl(var(--warm-brown))] mb-4">
            {t('collections.title')}
          </h2>
          <p className="text-[hsl(var(--muted-foreground))] max-w-xl mx-auto">
            {t('collections.subtitle')}
          </p>
        </div>

        {/* Collections Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Large Featured Item */}
          <Link
            to={`/collections/${categories[0].id}`}
            className="group relative sm:col-span-2 lg:col-span-2 lg:row-span-2 overflow-hidden rounded-2xl aspect-square lg:aspect-auto"
          >
            <div className="img-zoom h-full">
              <img
                src={categories[0].image}
                alt={t(`collections.${categories[0].id}`)}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute inset-0 gradient-overlay" />
            <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8">
              <div className="flex items-end justify-between">
                <div>
                  <h3 className="font-display text-2xl md:text-3xl font-semibold text-white mb-2">
                    {t(`collections.${categories[0].id}`)}
                  </h3>
                  <p className="text-white/80 text-sm">
                    24 {t('products.products')}
                  </p>
                </div>
                <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:bg-white group-hover:scale-110 transition-all duration-300">
                  <ArrowUpRight className="w-5 h-5 text-white group-hover:text-[hsl(var(--warm-brown))] transition-colors" />
                </div>
              </div>
            </div>
          </Link>

          {/* Other Categories */}
          {categories.slice(1).map((category, index) => (
            <Link
              key={category.id}
              to={`/collections/${category.id}`}
              className="group relative overflow-hidden rounded-2xl aspect-square"
            >
              <div className="img-zoom h-full">
                <img
                  src={category.image}
                  alt={t(`collections.${category.id}`)}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute inset-0 gradient-overlay" />
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <div className="flex items-end justify-between">
                  <div>
                    <h3 className="font-display text-xl font-semibold text-white mb-1">
                      {t(`collections.${category.id}`)}
                    </h3>
                    <p className="text-white/80 text-xs">
                      {18 + index * 6} {t('products.products')}
                    </p>
                  </div>
                  <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:bg-white group-hover:scale-110 transition-all duration-300">
                    <ArrowUpRight className="w-4 h-4 text-white group-hover:text-[hsl(var(--warm-brown))] transition-colors" />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <Link
            to="/collections"
            className="inline-flex items-center gap-2 text-[hsl(var(--warm-brown))] font-medium hover:underline underline-animation"
          >
            {t('collections.viewAll')}
            <ArrowUpRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
