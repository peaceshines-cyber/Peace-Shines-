import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export default function Contact() {
  const { t } = useTranslation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    toast.success(t('contact.success'));
    setFormData({ name: '', email: '', subject: '', message: '' });
    setIsSubmitting(false);
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: t('contact.address'),
      content: '123 Jewelry Street, Fashion District, NY 10001',
    },
    {
      icon: Phone,
      title: t('contact.phone'),
      content: '+1 (555) 123-4567',
    },
    {
      icon: Mail,
      title: 'Email',
      content: 'hello@peaceshines.com',
    },
    {
      icon: Clock,
      title: t('contact.hours'),
      content: 'Mon - Sat: 9:00 AM - 6:00 PM',
    },
  ];

  return (
    <section className="section-padding bg-[hsl(var(--champagne))]/30">
      <div className="container-elegant">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-sm font-medium text-[hsl(var(--accent))] tracking-widest uppercase mb-4">
            {t('contact.title')}
          </span>
          <h2 className="font-display text-4xl md:text-5xl font-semibold text-[hsl(var(--warm-brown))] mb-4">
            {t('contact.title')}
          </h2>
          <p className="text-[hsl(var(--muted-foreground))] max-w-xl mx-auto">
            {t('contact.subtitle')}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Contact Info */}
          <div>
            <div className="grid sm:grid-cols-2 gap-6 mb-8">
              {contactInfo.map((info, index) => (
                <div
                  key={index}
                  className="p-6 bg-[hsl(var(--card))] rounded-2xl hover:shadow-lg transition-shadow"
                >
                  <div className="w-12 h-12 bg-[hsl(var(--champagne))] rounded-xl flex items-center justify-center mb-4">
                    <info.icon className="w-6 h-6 text-[hsl(var(--warm-brown))]" />
                  </div>
                  <h3 className="font-medium text-[hsl(var(--foreground))] mb-2">
                    {info.title}
                  </h3>
                  <p className="text-sm text-[hsl(var(--muted-foreground))]">
                    {info.content}
                  </p>
                </div>
              ))}
            </div>

            {/* Map Placeholder */}
            <div className="aspect-video bg-[hsl(var(--muted))] rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1524661135-423995f22d0b?w=800&h=450&fit=crop"
                alt="Location Map"
                className="w-full h-full object-cover opacity-60"
              />
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-[hsl(var(--card))] p-8 md:p-10 rounded-2xl shadow-sm">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-[hsl(var(--foreground))]">
                    {t('contact.name')}
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Your name"
                    required
                    className="bg-[hsl(var(--background))] border-[hsl(var(--border))] focus:border-[hsl(var(--warm-brown))] focus:ring-[hsl(var(--warm-brown))]"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-[hsl(var(--foreground))]">
                    {t('contact.email')}
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="your@email.com"
                    required
                    className="bg-[hsl(var(--background))] border-[hsl(var(--border))] focus:border-[hsl(var(--warm-brown))] focus:ring-[hsl(var(--warm-brown))]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject" className="text-[hsl(var(--foreground))]">
                  {t('contact.subject')}
                </Label>
                <Input
                  id="subject"
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="How can we help?"
                  required
                  className="bg-[hsl(var(--background))] border-[hsl(var(--border))] focus:border-[hsl(var(--warm-brown))] focus:ring-[hsl(var(--warm-brown))]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message" className="text-[hsl(var(--foreground))]">
                  {t('contact.message')}
                </Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Tell us more about your inquiry..."
                  required
                  rows={5}
                  className="bg-[hsl(var(--background))] border-[hsl(var(--border))] focus:border-[hsl(var(--warm-brown))] focus:ring-[hsl(var(--warm-brown))] resize-none"
                />
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full btn-elegant"
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Sending...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Send className="w-4 h-4" />
                    {t('contact.send')}
                  </span>
                )}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
