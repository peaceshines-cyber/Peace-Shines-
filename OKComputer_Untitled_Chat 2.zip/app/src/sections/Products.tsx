import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { ShoppingBag, Star, Eye, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { getFeaturedProducts } from '@/data/products';
import { useCart } from '@/context/CartContext';
import { useState } from 'react';

export default function Products() {
  const { t } = useTranslation();
  const { addItem } = useCart();
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  
  const products = getFeaturedProducts();

  const handleAddToCart = (product: typeof products[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
    });
  };

  return (
    <section className="section-padding bg-[hsl(var(--champagne))]/30">
      <div className="container-elegant">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
          <div>
            <span className="inline-block text-sm font-medium text-[hsl(var(--accent))] tracking-widest uppercase mb-4">
              {t('products.title')}
            </span>
            <h2 className="font-display text-4xl md:text-5xl font-semibold text-[hsl(var(--warm-brown))]">
              {t('products.title')}
            </h2>
          </div>
          <p className="text-[hsl(var(--muted-foreground))] max-w-md mt-4 md:mt-0">
            {t('products.subtitle')}
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="group bg-[hsl(var(--card))] rounded-2xl overflow-hidden card-elegant"
              onMouseEnter={() => setHoveredId(product.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              {/* Image Container */}
              <div className="relative aspect-square overflow-hidden bg-[hsl(var(--muted))]">
                <Link to={`/product/${product.id}`}>
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </Link>
                
                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  {product.isNew && (
                    <Badge className="bg-[hsl(var(--accent))] text-white text-xs">
                      New
                    </Badge>
                  )}
                  {product.isBestseller && (
                    <Badge className="bg-[hsl(var(--warm-brown))] text-white text-xs">
                      Bestseller
                    </Badge>
                  )}
                  {product.originalPrice && (
                    <Badge className="bg-red-500 text-white text-xs">
                      Sale
                    </Badge>
                  )}
                </div>

                {/* Quick Actions */}
                <div className={`absolute top-3 right-3 flex flex-col gap-2 transition-all duration-300 ${
                  hoveredId === product.id ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
                }`}>
                  <button className="w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-[hsl(var(--warm-brown))] hover:text-white transition-colors">
                    <Heart className="w-4 h-4" />
                  </button>
                  <Link
                    to={`/product/${product.id}`}
                    className="w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-[hsl(var(--warm-brown))] hover:text-white transition-colors"
                  >
                    <Eye className="w-4 h-4" />
                  </Link>
                </div>

                {/* Add to Cart Button */}
                <div className={`absolute bottom-0 left-0 right-0 p-3 transition-all duration-300 ${
                  hoveredId === product.id ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-full'
                }`}>
                  <Button
                    onClick={() => handleAddToCart(product)}
                    className="w-full bg-[hsl(var(--warm-brown))] hover:bg-[hsl(var(--deep-bronze))] text-white"
                  >
                    <ShoppingBag className="w-4 h-4 mr-2" />
                    {t('products.addToCart')}
                  </Button>
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                <Link to={`/product/${product.id}`}>
                  <h3 className="font-display text-lg font-medium text-[hsl(var(--foreground))] hover:text-[hsl(var(--warm-brown))] transition-colors line-clamp-1">
                    {product.name}
                  </h3>
                </Link>
                
                {/* Rating */}
                <div className="flex items-center gap-1 mt-2">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="text-sm text-[hsl(var(--muted-foreground))]">
                    {product.rating}
                  </span>
                  <span className="text-sm text-[hsl(var(--muted-foreground))]">
                    ({product.reviews})
                  </span>
                </div>

                {/* Price */}
                <div className="flex items-center gap-2 mt-2">
                  <span className="font-display text-xl font-semibold text-[hsl(var(--warm-brown))]">
                    ${product.price.toFixed(2)}
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm text-[hsl(var(--muted-foreground))] line-through">
                      ${product.originalPrice.toFixed(2)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <Link to="/products">
            <Button
              variant="outline"
              size="lg"
              className="btn-outline-elegant"
            >
              {t('collections.viewAll')}
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
