import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, User, Menu, Globe, Search, Heart } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetClose,
} from '@/components/ui/sheet';

const languages = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'ar', name: 'العربية', flag: '🇸🇦' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
];

export default function Header() {
  const { t, i18n } = useTranslation();
  const location = useLocation();
  const { totalItems } = useCart();
  const { isAuthenticated, logout } = useAuth();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const changeLanguage = (langCode: string) => {
    i18n.changeLanguage(langCode);
    document.documentElement.dir = langCode === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = langCode;
  };

  const navLinks = [
    { path: '/', label: t('nav.home') },
    { path: '/collections', label: t('nav.collections') },
    { path: '/products', label: t('nav.products') },
    { path: '/about', label: t('nav.about') },
    { path: '/contact', label: t('nav.contact') },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-[hsl(var(--cream))]/95 backdrop-blur-md shadow-sm'
          : 'bg-transparent'
      }`}
    >
      <div className="container-elegant">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <span className="font-display text-2xl md:text-3xl font-semibold tracking-wide text-[hsl(var(--warm-brown))]">
              Peace Shines
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`font-body text-sm tracking-wide underline-animation ${
                  isActive(link.path)
                    ? 'text-[hsl(var(--warm-brown))] font-medium'
                    : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--warm-brown))]'
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-3 md:gap-4">
            {/* Search */}
            <button className="p-2 hover:bg-[hsl(var(--muted))] rounded-full transition-colors hidden sm:flex">
              <Search className="w-5 h-5 text-[hsl(var(--muted-foreground))]" />
            </button>

            {/* Language Selector */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="p-2 hover:bg-[hsl(var(--muted))] rounded-full transition-colors hidden sm:flex items-center gap-1">
                  <Globe className="w-5 h-5 text-[hsl(var(--muted-foreground))]" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-[hsl(var(--card))]">
                {languages.map((lang) => (
                  <DropdownMenuItem
                    key={lang.code}
                    onClick={() => changeLanguage(lang.code)}
                    className={`cursor-pointer ${
                      i18n.language === lang.code ? 'bg-[hsl(var(--muted))]' : ''
                    }`}
                  >
                    <span className="mr-2">{lang.flag}</span>
                    {lang.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Wishlist */}
            <button className="p-2 hover:bg-[hsl(var(--muted))] rounded-full transition-colors hidden sm:flex">
              <Heart className="w-5 h-5 text-[hsl(var(--muted-foreground))]" />
            </button>

            {/* Cart */}
            <Link to="/cart" className="relative p-2 hover:bg-[hsl(var(--muted))] rounded-full transition-colors">
              <ShoppingBag className="w-5 h-5 text-[hsl(var(--muted-foreground))]" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-[hsl(var(--warm-brown))] text-[hsl(var(--cream))] text-xs rounded-full flex items-center justify-center font-medium">
                  {totalItems}
                </span>
              )}
            </Link>

            {/* User */}
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="p-2 hover:bg-[hsl(var(--muted))] rounded-full transition-colors hidden sm:flex">
                    <User className="w-5 h-5 text-[hsl(var(--muted-foreground))]" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-[hsl(var(--card))]">
                  <DropdownMenuItem onClick={logout} className="cursor-pointer">
                    {t('nav.logout')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link
                to="/login"
                className="p-2 hover:bg-[hsl(var(--muted))] rounded-full transition-colors hidden sm:flex"
              >
                <User className="w-5 h-5 text-[hsl(var(--muted-foreground))]" />
              </Link>
            )}

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <button className="lg:hidden p-2 hover:bg-[hsl(var(--muted))] rounded-full transition-colors">
                  <Menu className="w-6 h-6 text-[hsl(var(--muted-foreground))]" />
                </button>
              </SheetTrigger>
              <SheetContent side={i18n.language === 'ar' ? 'right' : 'left'} className="bg-[hsl(var(--cream))]">
                <div className="flex flex-col h-full">
                  <div className="flex items-center justify-between mb-8">
                    <span className="font-display text-2xl font-semibold text-[hsl(var(--warm-brown))]">
                      Peace Shines
                    </span>
                  </div>
                  
                  <nav className="flex flex-col gap-4">
                    {navLinks.map((link) => (
                      <SheetClose asChild key={link.path}>
                        <Link
                          to={link.path}
                          className={`text-lg font-body py-2 border-b border-[hsl(var(--border))] ${
                            isActive(link.path)
                              ? 'text-[hsl(var(--warm-brown))] font-medium'
                              : 'text-[hsl(var(--muted-foreground))]'
                          }`}
                        >
                          {link.label}
                        </Link>
                      </SheetClose>
                    ))}
                  </nav>

                  <div className="mt-auto pt-8">
                    <div className="flex items-center gap-4 mb-4">
                      <span className="text-sm text-[hsl(var(--muted-foreground))]">
                        {t('nav.language')}:
                      </span>
                      <div className="flex gap-2">
                        {languages.map((lang) => (
                          <button
                            key={lang.code}
                            onClick={() => changeLanguage(lang.code)}
                            className={`px-3 py-1 text-sm rounded-full border ${
                              i18n.language === lang.code
                                ? 'bg-[hsl(var(--warm-brown))] text-[hsl(var(--cream))] border-[hsl(var(--warm-brown))]'
                                : 'border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))]'
                            }`}
                          >
                            {lang.flag}
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    {!isAuthenticated && (
                      <div className="flex gap-3">
                        <SheetClose asChild>
                          <Link to="/login" className="flex-1">
                            <Button variant="outline" className="w-full">
                              {t('nav.login')}
                            </Button>
                          </Link>
                        </SheetClose>
                        <SheetClose asChild>
                          <Link to="/register" className="flex-1">
                            <Button className="w-full bg-[hsl(var(--warm-brown))]">
                              {t('nav.register')}
                            </Button>
                          </Link>
                        </SheetClose>
                      </div>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
