import { useTranslation } from 'react-i18next';
import { Gem, Heart, Award, Sparkles } from 'lucide-react';

export default function About() {
  const { t } = useTranslation();

  const values = [
    {
      icon: Gem,
      title: t('about.quality'),
      description: t('about.qualityText'),
    },
    {
      icon: Heart,
      title: t('about.affordable'),
      description: t('about.affordableText'),
    },
    {
      icon: Award,
      title: t('about.timeless'),
      description: t('about.timelessText'),
    },
  ];

  return (
    <section className="section-padding bg-[hsl(var(--background))]">
      <div className="container-elegant">
        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center mb-20">
          {/* Image Side */}
          <div className="relative">
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1617038220319-276d3cfab638?w=800&h=1000&fit=crop"
                alt="Jewelry Craftsmanship"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Decorative Frame */}
            <div className="absolute -top-4 -left-4 w-full h-full border-2 border-[hsl(var(--warm-brown))]/20 rounded-2xl -z-10" />
            {/* Experience Badge */}
            <div className="absolute -bottom-6 -right-6 bg-[hsl(var(--warm-brown))] text-white p-6 rounded-2xl shadow-xl">
              <p className="font-display text-4xl font-bold">5+</p>
              <p className="text-sm opacity-80">Years of<br />Excellence</p>
            </div>
          </div>

          {/* Content Side */}
          <div>
            <span className="inline-block text-sm font-medium text-[hsl(var(--accent))] tracking-widest uppercase mb-4">
              {t('about.story')}
            </span>
            <h2 className="font-display text-4xl md:text-5xl font-semibold text-[hsl(var(--warm-brown))] mb-6">
              {t('about.title')}
            </h2>
            <p className="text-lg text-[hsl(var(--muted-foreground))] leading-relaxed mb-6">
              {t('about.storyText')}
            </p>
            <p className="text-[hsl(var(--muted-foreground))] leading-relaxed mb-8">
              {t('about.missionText')}
            </p>
            
            {/* Signature */}
            <div className="flex items-center gap-4 pt-6 border-t border-[hsl(var(--border))]">
              <div className="w-12 h-12 bg-[hsl(var(--champagne))] rounded-full flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-[hsl(var(--warm-brown))]" />
              </div>
              <div>
                <p className="font-display text-lg font-semibold text-[hsl(var(--warm-brown))]">
                  Peace Shines
                </p>
                <p className="text-sm text-[hsl(var(--muted-foreground))]">
                  Est. 2020
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Values */}
        <div className="grid md:grid-cols-3 gap-8">
          {values.map((value, index) => (
            <div
              key={index}
              className="group p-8 bg-[hsl(var(--card))] rounded-2xl hover:shadow-xl transition-all duration-500 hover:-translate-y-2"
            >
              <div className="w-14 h-14 bg-[hsl(var(--champagne))] rounded-xl flex items-center justify-center mb-6 group-hover:bg-[hsl(var(--warm-brown))] transition-colors duration-300">
                <value.icon className="w-7 h-7 text-[hsl(var(--warm-brown))] group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-display text-xl font-semibold text-[hsl(var(--warm-brown))] mb-3">
                {value.title}
              </h3>
              <p className="text-[hsl(var(--muted-foreground))] leading-relaxed">
                {value.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
